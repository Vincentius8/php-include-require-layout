<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Index Page (No Header & Footer)</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<?php
include 'header.php';
?>

  <!-- Main Content -->
  <div class="container my-5">
    <h1 class="text-center">Welcome to My Website 🚀</h1>

    <!-- Example Content -->
    <div class="row mt-5">
      <div class="col-md-4">
        <div class="card shadow-sm">
          <div class="card-body">
            <h5 class="card-title">Section 1</h5>
            <p class="card-text">Your content goes here.</p>
            <a href="#" class="btn btn-primary">Learn More</a>
          </div>
        </div>
      </div>
      
      <div class="col-md-4">
        <div class="card shadow-sm">
          <div class="card-body">
            <h5 class="card-title">Section 2</h5>
            <p class="card-text">Your content goes here.</p>
            <a href="#" class="btn btn-success">Explore</a>
          </div>
        </div>
      </div>
      
      <div class="col-md-4">
        <div class="card shadow-sm">
          <div class="card-body">
            <h5 class="card-title">Section 3</h5>
            <p class="card-text">Your content goes here.</p>
            <a href="#" class="btn btn-warning">Get Started</a>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- Bootstrap JS -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

  <?php
  include 'footer.php';
  ?>
</body>
</html>

