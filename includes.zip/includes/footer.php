<!-- footer.html -->
<footer class="bg-dark text-light pt-4 pb-2 mt-5">
  <div class="container">
    <div class="row">
      
      <!-- Column 1 -->
      <div class="col-md-4 mb-3">
        <h5 class="fw-bold">MyWebsite</h5>
        <p class="small">
          Your trusted site for learning and innovation.  
          Helping students and developers since 2025 🚀
        </p>
      </div>
      
      <!-- Column 2 -->
      <div class="col-md-4 mb-3">
        <h5 class="fw-bold">Quick Links</h5>
        <ul class="list-unstyled">
          <li><a href="#" class="text-light text-decoration-none">🏠 Home</a></li>
          <li><a href="#" class="text-light text-decoration-none">📖 About</a></li>
          <li><a href="#" class="text-light text-decoration-none">🛠 Services</a></li>
          <li><a href="#" class="text-light text-decoration-none">📩 Contact</a></li>
        </ul>
      </div>
      
      <!-- Column 3 -->
      <div class="col-md-4 mb-3">
        <h5 class="fw-bold">Follow Us</h5>
        <a href="#" class="text-light me-3"><i class="bi bi-facebook"></i> Facebook</a><br>
        <a href="#" class="text-light me-3"><i class="bi bi-twitter"></i> Twitter</a><br>
        <a href="#" class="text-light"><i class="bi bi-github"></i> GitHub</a>
      </div>
    </div>
    <hr class="border-light">
    <div class="text-center small">
      © 2025 MyWebsite | All Rights Reserved
    </div>
  </div>
</footer>

<!-- Bootstrap Icons -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css">
